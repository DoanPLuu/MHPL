const FooterComponent = () => {
  return (
    <div>
        <footer className='footer'>
            <span>All rights reserved 2025 by SGU</span>
        </footer>
    </div>
  )
}

export default FooterComponent